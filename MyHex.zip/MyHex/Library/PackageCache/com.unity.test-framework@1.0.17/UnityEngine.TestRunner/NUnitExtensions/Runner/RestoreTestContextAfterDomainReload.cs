namespace UnityEngine.TestRunner.NUnitExtensions.Runner
{
    internal class RestoreTestContextAfterDomainReload {}
}
