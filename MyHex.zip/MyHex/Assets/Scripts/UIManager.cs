﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIManager : ClassManager
{
    public Text score, moves, highscoreTxt;
    public GameObject gameOverScreen, mainScreen;
    public List<Color> availableColors;
    public bool tick;

    public int boardWidth = 8, boardHeight = 9;
    //
    static public int movesCount;

    private GameManager GridManagerObject;
    private int blownHexagons;
    private int bombCount;

    public static UIManager instance;
    //
    static public void setMovesCount(int x = 0) { movesCount = x; }
    static public int getMovesCount() { return movesCount; }
    //
    void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(this);
    }

    void Start()
    {
        bombCount = 0;
        GridManagerObject = GameManager.instance;
        blownHexagons = 0;
        highscoreTxt.text = "Highscore: " + PlayerPrefs.GetInt("Highscore");
        //movesCount = 0;
        setMovesCount();
    }

    void Update()
    {
        if (tick)
        {
            StartGameButton();
            tick = false;
        }
    }

    public void Score(int x)
    {
        int tmpScore;
        blownHexagons += x;

        tmpScore = (SCORE_CONSTANT * blownHexagons);
        score.text = tmpScore.ToString();

        if (Int32.Parse(score.text) > BOMB_SCORE_THRESHOLD * bombCount + BOMB_SCORE_THRESHOLD)
        {
            ++bombCount;
            GridManagerObject.SetBombProduction();
        }
        if (tmpScore > PlayerPrefs.GetInt("Highscore"))
        {
            PlayerPrefs.SetInt("Highscore", tmpScore);
        }

    }

    public void UpdateMoves()
    {
        movesCount++;
        moves.text = movesCount.ToString();
    }

    public void GameOver()
    {
        gameOverScreen.SetActive(true);
    }

    public void BackButton()
    {
        SceneManager.LoadScene(0);
    }

    public void StartGameButton()
    {

        mainScreen.SetActive(false);

        GridManagerObject.SetGridHeight(boardHeight);
        GridManagerObject.SetGridWidth(boardWidth);

        List<Color> colors = new List<Color>();

        for (int i = 0; i < availableColors.Count; i++)
        {
            colors.Add(new Color(availableColors[i].r, availableColors[i].g, availableColors[i].b));
        }

        GridManagerObject.SetColorList(colors);
        GridManagerObject.InitializeGrid();
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
