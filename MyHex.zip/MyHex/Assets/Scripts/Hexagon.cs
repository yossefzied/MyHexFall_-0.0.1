﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//sub class inhereted from ClassManager
public class Hexagon : ClassManager
{
    //class variables
    GameManager gameManager;
    public int x, y;
    public Color color;
    public Vector2 lerpPosition;
    public bool lerp, bomb;
    public Vector2 speed;
    private int bombTimer;
    private TextMesh text;

    public struct NeighbourHexes
    {
        public Vector2 up;
        public Vector2 upLeft;
        public Vector2 upRight;
        public Vector2 down;
        public Vector2 downLeft;
        public Vector2 downRight;
    }

    //class functions:

    //set & get variables values
    #region Set & Get
    public void SetX(int value) { x = value; }
    public void SetY(int value) { y = value; }
    public void SetColor(Color newColor) { GetComponent<SpriteRenderer>().color = newColor; color = newColor; }
    public void Tick() { --bombTimer; text.text = bombTimer.ToString(); }
    public int GetX() { return x; }
    public int GetY() { return y; }
    public Color GetColor() { return GetComponent<SpriteRenderer>().color; }
    public int GetTimer() { return bombTimer; }
    #endregion

    void Start()
    {
        gameManager = GameManager.instance;
        lerp = false;
    }

    void Update()
    {
        if (lerp)
        {
            float newX = Mathf.Lerp(transform.position.x, lerpPosition.x, Time.deltaTime * HEXAGON_ROTATE_CONSTANT);
            float newY = Mathf.Lerp(transform.position.y, lerpPosition.y, Time.deltaTime * HEXAGON_ROTATE_CONSTANT);
            transform.position = new Vector2(newX, newY);


            if (Vector3.Distance(transform.position, lerpPosition) < HEXAGON_ROTATE_THRESHOLD)
            {
                transform.position = lerpPosition;
                lerp = false;
            }
        }
    }

    //Func. for changed rotation save
    public void Rotate(int newX, int newY, Vector2 newPos)
    {
        lerpPosition = newPos;
        SetX(newX);
        SetY(newY);
        lerp = true;
    }
    //check if the hex is rotating or stoped
    public bool IsRotating()
    {
        return lerp;
    }
    //check if the hex is moving or not
    public bool IsMoving()
    {
        return !(GetComponent<Rigidbody2D>().velocity == Vector2.zero);
    }
    //make hex expload when it needs to disappear
    public void Exploded()
    {
        GetComponent<Collider2D>().isTrigger = true;
    }
    //get hex 6 neighbours from all directions
    public NeighbourHexes GetNeighbours()
    {
        NeighbourHexes neighbours;
        bool onStepper = gameManager.OnStepper(GetX());

        neighbours.down = new Vector2(x, y - 1);
        neighbours.up = new Vector2(x, y + 1);
        neighbours.upLeft = new Vector2(x - 1, onStepper ? y + 1 : y);
        neighbours.upRight = new Vector2(x + 1, onStepper ? y + 1 : y);
        neighbours.downLeft = new Vector2(x - 1, onStepper ? y : y - 1);
        neighbours.downRight = new Vector2(x + 1, onStepper ? y : y - 1);

        return neighbours;
    }
    //Sets new world pos for hexes
    public void ChangeWorldPosition(Vector2 newPosition)
    {
        lerpPosition = newPosition;
        lerp = true;
    }
    //Sets new board pos for hexes
    public void ChangeGridPosition(Vector2 newPosition)
    {
        x = (int)newPosition.x;
        y = (int)newPosition.y;
    }
    //put a bomb into grid and set random timer for it
    public void SetBomb()
    {
        text = new GameObject().AddComponent<TextMesh>();
        text.alignment = TextAlignment.Center;
        text.anchor = TextAnchor.MiddleCenter;
        text.transform.localScale = transform.localScale;
        text.transform.position = new Vector3(transform.position.x, transform.position.y, -4);
        text.color = Color.black;
        text.transform.parent = transform;
        //bombTimer = BOMB_TIMER_START;
        bombTimer = Random.Range(5,11);
        text.text = bombTimer.ToString();
    }

}
