﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//sub class inhereted from Hexagon
public class Bomb : Hexagon
{
    //class variables
    public TextMesh output;
    private int clock;

    //class functions:
    
    //tick for bomb's clock each turn pass
    public void BombTick() { --clock; output.text = clock.ToString(); }
    //get clock value
    public int GetClock() { return clock; }
    //set clock value
    public void SetClock(int value) { clock = value; output.text = clock.ToString(); }

}
